import React from "react";
import Footer from "../Components/Footer";
import HowItWorks from "../Components/HowItWorks";

export default function HowItWork() {
  return (                   
    <div>
      <HowItWorks />             
      <Footer />                 
    </div>
  );
}
